module.exports = {
  reactStrictMode: true,
  images: {
    domains: ["www.jennexplores.com", "upload.wikimedia.org"],
  },
};
